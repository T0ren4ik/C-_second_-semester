#include "Header.h"


int main() {
	create_obj_file("object.txt");


	return 0;
}