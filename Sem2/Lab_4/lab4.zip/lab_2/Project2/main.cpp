#include "point.h"

int main() {
	Point a(2, 3);
	Point b(4, 4);
	cout << max__type_t(a, b);
	
	//int r = 1;

	//Fract f1(2, 3), f2(3), f3(1, 2), f4(1,1);

	//Fract F6;
	//cout << "f1=" << f1 << endl;
	//cout << "f2=" << f2 << endl;
	//cout << "f3=" << f3 << endl;
	//Fract res = f1 + f2;
	//cout << res << endl;
	//res = f1 + f3;
	////cout << res << endl;
	//Fract sum;
	//sum = sum + f1;
	//sum = sum + f2;
	//sum = sum + f3;
	//cout << sum << endl;

	//cin >> F6;
	//cout << F6;



	//Time T = Time(14, 12, 50);
	//Time F = Time();
	//Time N = Time(14, 18, 26);

	//Time res = T + N;
	//cout << res << endl;

	//res = N - T;
	//cout << res << endl;

	//res++;
	//cout << res << endl;

	//++res;
	//cout << res << endl;

	//cin >> F;
	//cout << F;

	

	//system("pause");
	return 0;
}