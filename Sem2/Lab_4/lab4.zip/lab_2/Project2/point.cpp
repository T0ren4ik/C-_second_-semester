#include <iostream>
#include "point.h"

Point::Point() {
    this->x = 0;
    this->y = 0;
    std::cout << "Point created - (" << this->x << ", " << this->y << ")" << std::endl;
}

Point::Point(double x, double y) {
    this->x = x;
    this->y = y;
    std::cout << "Point created - (" << this->x << ", " << this->y << ")" << std::endl;
}

Point::Point(const Point& p){
    this->x = p.x;
    this->y = p.y;
    std::cout << "Cop Point created - (" << this->x << ", " << this->y << ")" << std::endl;
}


double Point::get_x(){return this->x;}

double Point::get_y() {return this->y;}

void Point::set_x(double new_x){x = new_x;}

void Point::set_y(double new_y) {y = new_y;}

void Point::set_point(double new_x, double new_y){
    x = new_x;
    y = new_y;
}

void Point::shift_X(double dx){x += dx;}

void Point::shift_Y(double dy){y += dy;}

bool Point::isEqual(const Point& p){
    return ((x == p.x) && (y == p.y));
}

void Point::print(){cout << "x = " << x << " | y = " << y << endl;}

double Point::distance_to(const Point& other) const{
    return sqrt((x-other.x)* (x - other.x) + (y - other.y)* (y - other.y));
}

Point add1(Point a, Point b){
    double x_a = a.get_x(), y_a = a.get_y(), x_b = b.get_x(), y_b = b.get_y();
    return Point(x_a + x_b, y_a + y_b);
}

Point add2(const Point& a, const Point& b){
    
    return Point();
}
//
//template <>
//Point max__type_t(const Point& a, const Point& b) {
//    Point zero;
//    return (zero.distance_to(a) > zero.distance_to(b)) ? a : b;
//}

//==========================================================================================

Fract Fract::operator+(const Fract& other) {
    Fract temp;
    int d = this->denom * other.denom;
    int n = this->denom * other.numen + other.denom * this->numen;
    temp.denom = abs(d);
    temp.numen = abs(n);
    temp.sign = d * n > 0 ? 1 : -1;
    return temp;
}

Fract Fract::operator-(const Fract& other){
    Fract temp;
    int d = this->denom * other.denom;
    int n = this->denom * other.numen - other.denom * this->numen;
    temp.denom = abs(d);
    temp.numen = abs(n);
    temp.sign = d * n > 0 ? 1 : -1;
    return temp;
}

Fract Fract::operator*(const Fract& other){
    Fract temp;
    int d = this->denom * other.denom;
    int n = this->numen * other.numen;
    temp.denom = abs(d);
    temp.numen = abs(n);
    temp.sign = d * n > 0 ? 1 : -1;
    return temp;
}

Fract Fract::operator/(const Fract& other){
    Fract temp;
    int d = this->denom * other.numen;
    int n = this->numen * other.denom;
    temp.denom = abs(d);
    temp.numen = abs(n);
    temp.sign = d * n > 0 ? 1 : -1;
    return temp;
}

bool Fract::operator==(const Fract& other){
    return ((this->denom == denom) && (this->numen == numen)) ? 1 : 0;
}

bool Fract::operator>(const Fract& other){
    if ((this->numen*this->sign) > (numen*sign)) return 1;
    else if (this->numen == numen)
        if(this->denom > denom) return 1;
        else return 0;
    else return 0;
}

bool Fract::operator<(const Fract& other){
    if ((this->numen * this->sign) < (numen * sign)) return 1;
    else if (this->numen == numen)
        if (this->denom < denom) return 1;
        else return 0;
    else return 0;
}

bool Fract::operator>=(const Fract& other){
    if ((this->numen * this->sign) >= (numen * sign)) return 1;
    else if (this->numen == numen)
        if (this->denom >= denom) return 1;
        else return 0;
    else return 0;
}

bool Fract::operator<=(const Fract& other){
    if ((this->numen * this->sign) <= (numen * sign)) return 1;
    else if (this->numen == numen)
        if (this->denom <= denom) return 1;
        else return 0;
    else return 0;
}

bool Fract::operator!=(const Fract& other){
    return !(*this==other);
}

ostream& operator << (ostream& os, const Fract& fr) {
    os << fr.numen << " / " << fr.denom << endl;
    return os;
}

istream& operator >> (istream& os, Fract& fr){
    os >> fr.numen >> fr.denom ;
    if (fr.numen * fr.denom >= 0) fr.sign = 1;
    else if (fr.numen * fr.denom < 0) fr.sign = -1;
    else {
        fr.sign = 1;
        if (fr.numen < 0 || fr.denom < 0) fr.sign = -1;
    }
    fr.numen = abs(fr.numen);
    fr.denom = abs(fr.denom);
    return os;
}


//==========================================================================================


Time::Time(const Time& p) { this->sec = p.sec, this->min = p.min, this->ours = p.ours; }

void Time::customaz(Time& t) {
    int pr = t.sec % 60;
    min += t.sec / 60; t.sec = pr;
    pr = t.min % 60;
    t.ours += t.min / 60; t.min = pr;
    t.ours = t.ours % 24;
}


Time Time::operator+(const Time& other){
    int s = (this->sec + other.sec), m = (this->min + other.min), o = (this->ours + other.ours);
    Time t = Time(o, m, s);
    customaz(t);
    return t;
}

Time Time::operator-(const Time& other){
    int s = sec - other.sec, m = min - other.min, o = ours - other.ours;
    if (s < 0) {
        s += 60;
        m -= 1;
    }
    if (m < 0) {
        m += 60;
        o -= 1;
    }
    if (o < 0) {
        o += 23;
    }

    return Time(o, m, s);
}

Time& Time::operator=(const Time& other){
    if (this != &other) {
        sec = other.sec;
        min = other.min;
        ours = other.ours;
    }   
    return *this;
}

void Time::add_min(int a){this->min++;}

Time& Time::operator++(){
    this->add_min(1);
    return *this;
}

Time& Time::operator++(int){
    Time d = *this;
    add_min(1); 
    return d;
}

bool Time::operator==(const Time& other){return ((this->sec == sec) && (this->min) && (this->ours = ours));}

bool Time::operator>(const Time& other){
    if (this->ours > ours) return true;
    if (this->min > min) return true;
    if (this->sec > sec) return true;
    return false;
}

bool Time::operator<(const Time& other){
    if (this->ours < ours) return true;
    if (this->min < min) return true;
    if (this->sec < sec) return true;
    return false;
}

bool Time::operator>=(const Time& other){
    if (this->ours >= ours) return true;
    if (this->min >= min) return true;
    if (this->sec >= sec) return true;
    return false;
}

bool Time::operator<=(const Time& other){
    if (this->ours <= ours) return true;
    if (this->min <= min) return true;
    if (this->sec <= sec) return true;
    return false;
}

bool Time::operator!=(const Time& other){return !(*this==other);}

ostream& operator<<(ostream& os, const Time& t) { return os << t.ours << ":" << t.min << ":" << t.sec << endl; }

istream& operator>>(istream& os, Time& t){ 
    os  >> t.ours >> t.min >> t.sec; 
    return os;
}
