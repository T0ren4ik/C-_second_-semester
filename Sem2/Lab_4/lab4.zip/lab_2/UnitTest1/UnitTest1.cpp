#include "pch.h"
#include "CppUnitTest.h"
#include "..\Project2\point.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			Point p = Point(0, 0);
			Assert::AreEqual(p.get_x(), 0, 1e-5);
			Assert::AreEqual(p.get_y(), 0, 1e-5);

			Point pc = Point(p);
			Assert::IsTrue(pc.isEqual(p));

			p.set_x(4); p.set_y(5);
			Assert::AreEqual(p.get_x(), 4, 1e-5);
			Assert::AreEqual(p.get_y(), 5, 1e-5);

			p.set_point(3, 4);
			Assert::AreEqual(p.get_x(), 3, 1e-5);
			Assert::AreEqual(p.get_y(), 4, 1e-5);


		}
	};
}
