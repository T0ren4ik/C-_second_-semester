#include "pch.h"
#include "CppUnitTest.h"
#include "..\Project2\point.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest2
{
	TEST_CLASS(UnitTest2)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			Point p = Point(0, 0);
			Assert::AreEqual(p.get_x(), 0, 1e-5);
			Assert::AreEqual(p.get_y(), 0, 1e-5);

			Point pc = Point(p);
			Assert::IsTrue(pc.isEqual(p));

			p.set_x(4); p.set_y(5);
			Assert::AreEqual(p.get_x(), 4, 1e-5);
			Assert::AreEqual(p.get_y(), 5, 1e-5);

			p.set_point(3, 4);
			Assert::AreEqual(p.get_x(), 3, 1e-5);
			Assert::AreEqual(p.get_y(), 4, 1e-5);

			p.shift_X(6); p.shift_Y(12);
			Assert::AreEqual(p.get_x(), 9, 1e-5);
			Assert::AreEqual(p.get_y(), 16, 1e-5);

			pc.set_point(6, 12);
			Assert::AreEqual(p.distance_to(pc), 5, 1e-5);

			Point A = add1(pc, p);
			Assert::AreEqual(A.get_x(), 15, 1e-5);
			Assert::AreEqual(A.get_y(), 28, 1e-5);
		}
	};
}
