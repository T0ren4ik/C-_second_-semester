#pragma once
template <typename T>
T max_type_T(const T& a, const T& b) {
	return a > b ? a : b;
}
