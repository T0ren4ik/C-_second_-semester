#include "set.h"

bool work_with_file(string filename1, string filename2) {
	ifstream fin1(filename1);
	if (!fin1.is_open()) {
		cout << "Error!" << endl;
		throw - 1;
	}
	ifstream fin2(filename2);
	if (!fin2.is_open()) {
		cout << "Error!" << endl;
		throw - 1;
	}

	int x;
	set<int> S1;
	set<int> S2;

	while (!fin1.eof())
	{
		fin1 >> x;
		S1 += x;
	}

	while (!fin2.eof())
	{
		fin2 >> x;
		S2 += x;
	}
	return (S1 == S2);
}

int main() {
	setlocale(LC_ALL, "ru");
	//Tree<double> t(2, 1);
	//Tree<double> t1(2, 1);
	//t.printTree();
	//t1.printTree();

	//Tree<double> t2 = t.intersectionTree(t1);
	//t2.printTree();

	cout << work_with_file("el1.txt", "el2.txt");

	return 0;
}

