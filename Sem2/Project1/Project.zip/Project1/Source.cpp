#define _CRTDBG_MAP_ALLOC // ��� ��������� ������ ������
#include <stdlib.h>      //
#include <crtdbg.h>     //

#include "Header.h"


int main(){
	setlocale(LC_ALL, "Russian");
	List<int> L;
	List<int> Le;
	List<string> L1;
	L1.inTail("Hello");
	L1.inTail(" world");
	cout << L1;
	//cin >> L;
	/*L.inTail(1);	L.inTail(2);	L.inTail(3);	L.inTail(4);	L.inTail(5);	L.inTail(6);
	cout << L;
	cout << Le;*/



	//cout << "isEmpty: " << L.isEmpty() << " | " << Le.isEmpty() << endl;
	//cout << "size: " << L.size() << " | " << Le.size() << endl;
	///*L.inHead(0); L.inTail(10);
	//Le.inTail(10); Le.inHead(0);*/
	//cout << L;
	//cout << Le;
	/*try
	{
		L.delFirst(); L.delLast();
		Le.delFirst(); Le.delLast();
		cout << L;
		cout << Le;
		cout << "size: " << L.size() << " | " << Le.size() << endl;

	}
	catch (const std::exception& ex)
	{
		cout << ex.what() << endl;
	}*/
	


	auto ptrB = L.begin();
	auto ptrB1 = Le.begin();
	auto ptrE1 = Le.end();
	auto ptrE = L.end();
	//cout << "Empty: " << ptrB.empty() << " | " << ptrE.empty() << endl;
	//cout << *ptrB << endl;
	//cout << *(ptrB++) << endl;
	//
	/*try {
		Le.insert_next(ptrB1, 0);
		cout << Le;
	}
	catch (const exception& ex) {
		cout << ex.what() << endl;
	}*/
	//Le.insert_prev(ptrB, 0);
	//L.insert_prev(ptrB, 0);
	//L.insert_prev(ptrE, 0);
	//L.insert_prev(++ptrB, 0);
	//L.insert_next(ptrB, 0);
	//L.insert_next(++ptrB, 0);

	try {
		cout << *(--ptrE);
		cout << *(--ptrE1);
	}
	catch (const exception& ex) {
		cout << ex.what() << endl;
	}

	//L.del(ptrB); L.del(ptrE);
	////L.del(ptrB);
	cout << Le;
	//cout << *ptrB;

	//cout << *L.find(1);

	
	return 0;
	_CrtDumpMemoryLeaks();  // ��� ��������� ������ ������
}