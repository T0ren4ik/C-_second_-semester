#include "Header.h"

int main() {
	setlocale(LC_ALL, "rus");

	//string S = "BIN.dat";
	//create_b_f(S);

	//read_b_f(S);

	//change_first_last_b_f(S);
	//read_b_f(S);

	//BF_koord("koord.txt");
	//read_b_f("b_koord.dat");
	//point* p = find_point("b_koord.dat");
	//cout << p->x << " | " << p->y << endl;

	//BF_worker("people.txt");
	//create_table_worker_t("b_people.dat");
	
	change_gate("b_people.dat", 2, 1111);


	return 1;
}