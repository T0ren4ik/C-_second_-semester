Код написан на основе http://doc.crossplatform.ru/qt/4.4.3/tutorials-addressbook.html
