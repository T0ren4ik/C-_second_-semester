#include "tList.h"
#include "Tree.h"



int main() {
	setlocale(LC_ALL, "ru");
	//Tree t(5);
	//t.printTree();
	//t.deleteLeaves();
	//t.printTree();

	//cout << "\n\n\n\n";

	List l(4);
	l.duplication();
	cout << l;


	return 0;
}