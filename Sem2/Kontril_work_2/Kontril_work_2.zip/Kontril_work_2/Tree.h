#pragma once
#include <iostream>

using namespace std;


class Tree {
private:
	struct TNode;
	typedef TNode* node_ptr;
	struct TNode {
		int data;
		node_ptr lt, rt;
		TNode(int val = 0, node_ptr l = nullptr, node_ptr r = nullptr) : data(val), lt(l), rt(r) {}
	};

	node_ptr root;

	void copy(node_ptr t, node_ptr& newT) const;
	void delTree(node_ptr& t) const; 
	void printT(const node_ptr& t, ostream& os) const;
	void add(node_ptr& t, int a) const;
	void printRKL(node_ptr t, int skip = 0); 
	void delLea(node_ptr& t);
	bool equal(node_ptr t, node_ptr t2);

	node_ptr search(const node_ptr& t, int key) {
		if (!t) return 0;
		else if (t->data == key) return t;
		else if (t->data > key) 
			search(t->lt, key);
		else 
			search(t->rt, key);
	}
	node_ptr createTree(int n) {
		if (n > 0) {
			int x, d = n / 2;
			//cout << "Another element?";

			cin >> x;
			node_ptr res = new TNode(x, createTree(d), createTree(n - d - 1));
			return res;
		}
		else return nullptr;
	}
	//Удаление
	void deleteEl(node_ptr& t, int a);
	void deleteNode(node_ptr& t);
	void delLeftLeaf(node_ptr& t, int& repl);
public:
	Tree() : root(nullptr) {}
	Tree(const Tree& t); 
	Tree(int n) noexcept;
	~Tree(); 
	void addNode(int a); // узел добавляется по правилу дерева поиска
	Tree& operator=(const Tree& t);
	bool operator==(const Tree& t);
	void printTree() { // печать дерева
		printRKL(root);
		cout << "===================================\n";
	}
	void deleteLeaves();
	friend ostream& operator<<(ostream& os, const Tree &t) ;
};