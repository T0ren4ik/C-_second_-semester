#include "Header.h"

int main() {
	setlocale(LC_ALL, "rus");
	cout << "================ 1 =================" << endl;

	const char* s1 = "H ello wor ld!";
	const char* s2 = "Helldo world!";

	cout << str_cmp(s1, s2) << endl;

	cout << "================ 2 =================" << endl;
	const char* ss = "  t  ";

	cout <<	ss << ": ���������� ���� = " << word_count(ss) << endl;

	cout << "================ 3 =================" << endl;

	cout <<	s1 << ": ������ ���������  w:" << str_chr(s1, 'w') << endl;
		
	cout << "================ 4 =================" << endl;
	
	char s[] = "Helldo world!";
	remove_chr(s, 'l');
	cout << s << ": �������� l, �������� ������: " << s << endl;
		
	cout << "================ 5 =================" << endl;

	const int Max_Length = 256;
	char str[256] = "Hello world!";

	char c = ' ';
	const char* ctr_a = "all 3456789234567893456789";
	const char* substr = "123456789012345678k901234567890123456789012345678901234567890123456789012k345678901234567890123456789012345678901234k678901234567890k23456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678881234567890123456789012345678901234557890";

	cout << str << endl;
	try {
		insert_str(str, substr, c);
		cout << "��������:" << substr << " ����� " << c << endl;
		cout << str << endl;
		cout << endl;
	}
	catch (const char* S) {
		cout << S << endl;
	}

	char str1[256] = "Hello world!";

	try {
		insert_str(str1, ctr_a, c);
		cout << "��������:" << ctr_a << " ����� " << c << endl;

		cout << str1 << endl;
		cout << endl;

	}
	catch (const char* S) {
		cout << S << endl;
	}

	try {
		insert_str(str, ctr_a, '/');
		cout << "��������:" << ctr_a << " ����� /"  << endl;

		cout << str << endl;
		cout << endl;

	}
	catch (const char* S) {
		cout << S << endl;
	}

	return 0;
}