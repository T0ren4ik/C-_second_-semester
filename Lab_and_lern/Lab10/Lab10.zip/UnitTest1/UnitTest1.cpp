#include "pch.h"
#include "CppUnitTest.h"
#include "../Lab10/Header.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			//������� 1
			{
				const char* s1 = "H ello wor ld!";
				const char* s2 = "Hello world!";
				const char* s3 = "Hello world!";

				Assert::IsTrue(str_cmp(s1, s2));
				Assert::IsFalse(str_cmp(s3, s2));
			}

			//������� 2
			{			
			const char* s1 = "H ello wor ld!";
			const char* s2 = "Hello world!";
			const char* s3 = "Hello world!";

			Assert::AreEqual(word_count(s1), 4);
			Assert::AreEqual(word_count(s2), 2);
			}

			//������� 3
			{
				const char* s1 = "H ello wor ld!";
				const char* s2 = "Hello world!";


				Assert::AreEqual(str_chr(s1, 'w')[0], 'w');
				Assert::AreEqual(str_chr(s2, 'H')[0], 'H');
				Assert::AreEqual(str_chr(s2, 'A'), nullptr);

			}

			//������� 4
			{
				//{
				//	char* s3 = "Hello world!";
				//	char* s4 = "ello world!";
				//	remove_chr(s3, 'H');

				//	for (int i = 0; s3[i]; ++i) {
				//		Assert::AreEqual(s3[i], s4[i]);
				//	}
				//}


				{
					char* s3 = "Hello world!";
					char* s4 = "Hello world!";
					remove_chr(s3, 'R');

					for (int i = 0; s3[i]; ++i) {
						Assert::AreEqual(s3[i], s4[i]);
					}
				}
			}

			//������� 5
			{
				const int Max_Length = 256;
				char str[Max_Length] = "Hello world!";
				char strt[Max_Length] = "Hello all world!";
				char c = ' ';
				const char* ctr_a = "all ";

				insert_str(str, ctr_a, c);

				for (int i = 0; str[i]; ++i) {
					Assert::AreEqual(str[i], strt[i]);
				}

			}
			{
				const int Max_Length = 256;
				char str[Max_Length] = "Hello world!";
				char strt[Max_Length] = "Hall ello world!";
				char c = 'H';
				const char* ctr_a = "all ";

				insert_str(str, ctr_a, c);

				for (int i = 0; str[i]; ++i) {
					Assert::AreEqual(str[i], strt[i]);
				}
			}
			{
				const int Max_Length = 256;
				char str[Max_Length] = "Hello world!";
				char strt[Max_Length] = "Hello world!all ";
				char c = '!';
				const char* ctr_a = "all ";

				insert_str(str, ctr_a, c);

				for (int i = 0; str[i]; ++i) {
					Assert::AreEqual(str[i], strt[i]);
				}
			}
			{
				const int Max_Length = 256;
				char str[Max_Length] = "Hello world!";
				char strt[Max_Length] = "Hello world!all ";
				char c = '/';
				const char* ctr_a = "all ";

				try {
					insert_str(str, ctr_a, c);
					for (int i = 0; str[i]; ++i) {
						Assert::AreEqual(str[i], strt[i]);
					}
				}
				catch (const char*) {
					Assert::IsTrue(true); //��
				}
			
				
			}
			{
				const int Max_Length = 256;
				char str[256] = "Hello world!";
				const char* substr = "123456789012345678k901234567890123456789012345678901234567890123456789012k345678901234567890123456789012345678901234k678901234567890k23456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678881234567890123456789012345678901234557890";
				char strt[Max_Length] = "Hello 123456789012345678k901234567890123456789012345678901234567890123456789012k345678901234567890123456789012345678901234k678901234567890k2345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567888world!";
				char c = ' ';

				try {
					insert_str(str, substr, c);
					for (int i = 0; str[i]; ++i) {
						Assert::AreEqual(str[i], strt[i]);
					}
				}
				catch (const char*) {
					Assert::IsTrue(true); //��
				}


			}
		}
	};
}
