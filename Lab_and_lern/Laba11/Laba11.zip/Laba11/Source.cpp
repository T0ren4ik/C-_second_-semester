#include "Header.h"

int main() {
	setlocale(LC_ALL, "rus");

	string S = "  123     123   35 123";
	cout << count_vorgs(S) << endl;

	cout << "=============================\n";

	erase_str(S, "1");
	cout << S << endl;
	cout << "=============================\n";

	isert_str(S, "2", "Hello");
	cout << S << endl;

	cout << "=============================\n";
	del_max_vord(S);
	cout << S << endl;

	cout << "=============================\n";
	string S3 = "  321     0   35 0  123  0  ";

	replese_zet_vord_sub(S3, " C++ ");
	cout << S3 << endl;

	cout << "=============================\n";
	string S1 = "  321     0   35 0  123  ";

	revers_Nzchet_vord(S1);
	cout << S1 << endl;

	cout << "=============================\n";

	string S2 = "    C++   ,   ������     ����   !������ ���!�������.    ";
	normal_string(S2);
	cout << S2 << endl;

	return 0;
}