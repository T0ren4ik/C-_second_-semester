#pragma once
#include <iostream>
#include <string>

using namespace std;

struct n_A{
	int n;
	string* A;
	int* I;	
};


template<typename T>
void print_arr(T* arr, int n) {
	//int n = sizeof(arr) / sizeof(T);
	if (arr != nullptr) {
		for (int i = 0; i < n; ++i)
			cout << arr[i] << " ";
		cout << "\n";
	}
}
n_A split(string s);

int count_vorgs(string s);
void erase_str(string& s, const string sub);
void isert_str(string& s, const string sub, const string ins);
void del_max_vord(string& s);
void replese_zet_vord_sub(string& s, string sub);
void revers_Nzchet_vord(string& s);
void normal_string(string& s);
