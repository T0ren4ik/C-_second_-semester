#include "Header.h"

int main() {

	//cout << good_plus_des_total_number("1.23");

	add_start_str_f_count_nubber("H.txt");


	return 0;
}