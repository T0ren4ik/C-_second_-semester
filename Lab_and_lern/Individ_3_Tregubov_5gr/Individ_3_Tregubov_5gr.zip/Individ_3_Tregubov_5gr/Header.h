#pragma once
#include <iostream>
#include <cstring>
#include <iomanip>
#include <fstream>
#include <string>
#include <string>

using namespace std;

bool good_plus_des_total_number(const char* str);

void add_start_str_f_count_nubber(string name);