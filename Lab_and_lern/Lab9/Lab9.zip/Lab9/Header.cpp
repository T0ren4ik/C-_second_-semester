#include "Header.h"

void read_new(int**& matr, int& rows, int& cols) {

	if (matr == nullptr) {
		cout << "������� ���-�� �����: ";
		cin >> rows; 
		cout << "������� ���-�� ��������: ";
		cin >> cols; 

		matr = new int* [rows];
		for (int i = 0; i < rows; ++i) matr[i] = new int[cols];

		for (int i = 0; i < rows; i++){
			for (int j = 0; j < cols; j++){
				cout << "EL mass #" << i << "|" << j << ": ";
				cin >> matr[i][j];
			}
		}
	}
	else
		throw "������ ��������";
}

void printMatrix(int** matr, int rows, int cols) {
	// ��������������� ����� ��� ������������ ��������		
	cout.setf(ios::left);
	cout << setw(6);

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			cout << matr[i][j] << "\t";
		}
		cout << endl;
	}
}

void delete_matrix(int**& matr, int rows) {
	if (matr != nullptr) {
		for (int i = 0; i < rows; ++i) delete[] matr[i];
		delete[]matr;
	}
	else{
		throw "������� �������� ������������ ������";
	}
}

double ratio_mud_sum_and_side(int** m, int rows, int cols){

	int sum_mud = 0, sum_side = 0;

	for (int i = 0; i < rows; i++){
		sum_mud += m[i][i];
		sum_side += m[i][cols - i - 1];
	}

	//cout << sum_mud << " | " << sum_side << endl;

	if (sum_side) {
		return sum_mud / sum_side;
	}
	else
		throw "������� ������� �� ����";
}

void add_cols(int**& matr, int rows, int& cols){
	int** m = new int* [rows];
	for (int i = 0; i < rows; ++i) m[i] = new int[cols + 1];

	int i, j;
	for (i = 0; i < rows; ++i) {
		int min_pol = matr[i][0];
		for (j = 0; j < cols; ++j) {
			m[i][j] = matr[i][j];
			if ((min_pol < 0 || matr[i][j] < min_pol) && matr[i][j] > 0) {
				min_pol = matr[i][j];
			}
		}
		min_pol = (min_pol > 0) ? min_pol : 0;
		m[i][cols] = min_pol;
	}

	delete_matrix(matr, rows);
	cols++;

	matr = m;
}

void del_cols_and_rows(int**& matr, int& rows, int& cols){
	int im = 0, jm = 0, max_el = matr[0][0];
	for (int i = 0; i < rows; i++){
		for (int j = 0; j < cols; j++){
			if (max_el < matr[i][j]) {
				max_el = matr[i][j];
				im = i; jm = j;
			}
		}
	}

	del_rows(matr, rows, cols, im);

	for (int i = 0; i < rows; ++i) {
		for (int j = jm; j < cols; ++j) {
			matr[i][j] = matr[i + 1][j];
		}
	}
	cols--;


	int** m = new int* [rows];
	for (int i = 0; i < rows; ++i) m[i] = new int[cols];

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			m[i][j] = matr[i][j];
		}
	}

	delete_matrix(matr, rows + 1);
	matr = m;
}

void del_rows(int**& matr, int& rows, int cols, int c){
	for (int i = c; i < rows - 1; ++i) {
		swap(matr[i], matr[i + 1]);
	}
	rows--;
}

void del_rows_pred(int**& matr, int& rows, int cols, pred f){
	int del_m = rows;
	for (int i = 0; i < rows; i++){
		if (f(matr[i], cols)) {
			del_rows(matr, rows, cols, i);
		}
	}

	if (rows != 0) {
		int** m = new int* [rows];
		for (int i = 0; i < rows; ++i) m[i] = new int[cols];

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				m[i][j] = matr[i][j];
			}
		}

		delete_matrix(matr, del_m);

		matr = m;
	}
	else {
		delete_matrix(matr, del_m);

		matr = nullptr;
	}

}

bool rows_zero(int* a, int n){
	n--;

	if ((a[n] != 0)) {
		return false;
	}
	else if (n == 0) {
		return true;
	}
	return rows_zero(a, n);
}

bool rows_negative(int* a, int n){
	n--;

	if (a[n] >= 0){
		return false;
	}
	else if (n == -1) {
		return true;
	}
	return rows_negative(a, n);
}

