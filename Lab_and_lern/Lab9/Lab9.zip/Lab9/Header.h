#pragma once
#include <iostream>
#include <iomanip> 

using namespace std;


void read_new(int**& m, int& rows, int& cols);
void printMatrix(int** matr, int rows, int cols);
void delete_matrix(int**& m, int rows);
double ratio_mud_sum_and_side(int** m, int rows, int cols);
void add_cols(int**& matr, int rows, int& cols);
void del_cols_and_rows(int**& matr, int& rows, int& cols);
void del_rows(int**& matr, int& rows, int cols, int c);
typedef bool (*pred)(int*, int);
void del_rows_pred(int**& matr, int& rows, int cols, pred f);
bool rows_zero(int* a, int n);
bool rows_negative(int* a, int n);