#include "Header.h"

int main() {
	setlocale(LC_ALL, "rus");

	cout << "============== 1 ===============\n";

	int** matr = nullptr;
	int rows, columns;

	try {
		read_new(matr, rows, columns);
		printMatrix(matr, rows, columns);
	}
	catch (const char* S) {
		cout << S << endl;
	}

	cout << "============== 2 ===============\n";

	cout << "�������� �������" << endl;

	cout << "============== 3 ===============\n";

	try {
		cout << "ratio_mud_sum_and_side: " << ratio_mud_sum_and_side(matr, rows, columns) << endl;
	}
	catch (const char* S) {
		cout << S << endl;
	}

	cout << "============== 4 ===============\n";

	add_cols(matr, rows, columns);
	printMatrix(matr, rows, columns);

	cout << "============== 5 ===============\n";

	del_cols_and_rows(matr, rows, columns);
	printMatrix(matr, rows, columns);

	cout << "============== 6 ===============\n";

	int** matr1 = nullptr;
	int rows1, columns1;

	try {
		read_new(matr1, rows1, columns1);
		printMatrix(matr1, rows1, columns1);
	}
	catch (const char* S) {
		cout << S << endl;
	}
	cout << "\n";

	del_rows_pred(matr1, rows1, columns1, rows_zero);
	cout << "\n";
	printMatrix(matr1, rows1, columns1);

	del_rows_pred(matr1, rows1, columns1, rows_negative);
	cout << "\n";
	printMatrix(matr1, rows1, columns1);


	delete_matrix(matr, rows);
	delete_matrix(matr1, rows1);
	return 0;
}