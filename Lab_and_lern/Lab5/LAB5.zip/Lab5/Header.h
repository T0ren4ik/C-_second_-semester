#pragma once
#include <iostream>
#include <string>

using namespace std;


int sum_arr(const int* begin, const int* end);
void pr_arr(const int* A, const int* B, int* C, int n);
void print(const int* pi, int size);
void selectionSort(int* a, int n);