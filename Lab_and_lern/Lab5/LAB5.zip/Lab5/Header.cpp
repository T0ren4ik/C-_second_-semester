#include "Header.h"


int sum_arr(const int* begin, const int* end) {
	const int* pt;
	int sum = 0;
	for (pt = begin; pt != end; ++pt)
		sum += *pt;
	return sum;
}

void pr_arr(const int* A, const int* B, int *C, int n) {
	for (int i = 0; i < n; i++) {
		C[i] = A[i] * B[i];
	}
		
}

void print(const int* pi, int n){
	for (int i = 0; i < n; i++)
		cout << pi[i] << ' ';
	cout << "\n";
}

void selectionSort(int* a, int n) {
	int min;
	for (int i = 0; i < n - 1; ++i) {
		min = i;
		for (int j = i + 1; j < n; ++j)
			if (a[j] < a[min]) min = j;
		swap(a[i], a[min]);
	}
}
