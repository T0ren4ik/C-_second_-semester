#include "Header.h"

int main() {
	int array[] = { 1,2,3,4,5,6,7,8,9,10 };
	int n = sizeof array / sizeof(int);
	cout << "The sum of all =" << sum_arr(array, array + n) << endl;

	int arrayA[] = { 1,2,3,4,5,6,7,8,9,10 };
	int arrayB[] = { 1,2,3,4,5,6,7,8,9,10 };
	int C[10];

	int n1 = sizeof arrayA / sizeof(int);

	pr_arr(arrayA, arrayB, C, n1);
	print(C, n1);


	int S[] = {5, 8, 1, 3, 0, 7};
	selectionSort(S, 6);
	print(S, 6);

	return 0;
}