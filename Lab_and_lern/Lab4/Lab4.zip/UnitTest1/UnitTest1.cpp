#include "pch.h"
#include "CppUnitTest.h"
#include "..\Lab4\Header.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			Assert::AreEqual(NOD_INT(30, 10), 10, 1e-5);
			Assert::AreEqual(NOD_INT(455, 312), 13, 1e-5);
			Assert::AreEqual(NOD_REK(30, 10), 10, 1e-5);
			Assert::AreEqual(NOD_REK(455, 312), 13, 1e-5);


			Assert::AreEqual(bilding_numder(2, 6), 64, 1e-5);
			Assert::AreEqual(bilding_numder(5.5, 3), 166.375, 1e-1);
			Assert::AreEqual(bilding_numder(8, 2), 64, 1e-5);

		}
	};
}
