#include "Header.h"

double hyperbola(double x){
	if (x) 
		return 1 / x;
	throw "Attempt to divide by 0";
}

void chart(func f, double a, double b, int n){
	double pr = (b - a + 1) / n;

	cout << "_____________________________" << endl;

	cout.width(15);
	cout.setf(ios::left);
	cout << "x" << "|" << "F(x)" << endl;
	cout << "-----------------------------" << endl;

	while (a <= b) {

		try {
			cout.width(15);
			cout.setf(ios::left);
			cout << a << "|"  << f(a) << endl;
		}
		catch (const char*) {
			cout << 0 << "|" << "Not defined"  << endl;
		}
		
		a += pr;
	}
	cout << "_____________________________\n" << endl;
}

void print_numder(int a){
		cout << abs(a) % 10 << endl;
	
		if (a/ 10) {
		print_numder(a / 10);
	}

}

double F1(double x) {
	if (x)
		return 1 / (x * x);
	throw "Attempt to divide by 0";
	
}

double F2(double x) {
	if (x)
		return 1 / x;
	throw "Attempt to divide by 0";
}

int NOD_INT(int a, int b){
	a = abs(a);
	b = abs(b);
	while (a != b) {
		if (a > b)
			a -= b;
		else
			b -= a;
	}
	return a;
}

int NOD_REK(int a, int b) {
	a = abs(a);
	b = abs(b);
	if (a - b) {
		if (a >= b){
			a = a - b;
		NOD_REK(a, b);
		}
		else {
			b = b - a;
			NOD_REK(a, b);
		}
	}
	else
		return(a);

}

double bilding_numder(double x, int n){
	if (n == 1)
		return x;
	else
		return x * bilding_numder(x, n - 1);
}

