#pragma once
#include <iostream>
#include <string>
using namespace std;
typedef double (*func) (double);


double hyperbola(double x);
void chart(func f, double a, double b, int n);
void print_numder(int a);

double F1(double x);
double F2(double x);

int NOD_INT(int a, int b);
int NOD_REK(int a, int b);

double bilding_numder(double x, int n);

int formula();