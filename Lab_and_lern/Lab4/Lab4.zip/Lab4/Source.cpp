#include "Header.h"

int main() {
	cout << "// ============= #1 ====================\n";
	try {
		cout << hyperbola(0) << endl;
	}
 	catch (const char* S) {
		cout << S << endl;
	}

	cout << "// ============= #2 ====================\n";
	cout << " " << endl;
	chart(F2, -1, 5, 7);


	cout << "// ============= #3 ====================\n";
	cout << " " << endl;
	chart(F1, -1, 5, 7);


	cout << "// ============= #4 ====================\n";
	print_numder(1234);
	cout << "======\n";
	print_numder(0);
	cout << "======\n";
	print_numder(-1234);

	cout << "// ============= #5 ====================\n";
	cout << NOD_INT(30, 10) << endl;
	cout << NOD_REK(72, 24) << endl;
	cout << "// ============= #6 ====================\n";
	cout << bilding_numder(2, 6) << endl;
	cout << bilding_numder(2.2, 6) << endl;



}