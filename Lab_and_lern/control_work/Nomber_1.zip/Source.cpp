#include "Header.h"
int main() {
	cout << Sum_N(3) << endl;
	cout << Sum_N(1) << endl;
	cout << Sum_N(10) << endl;
}