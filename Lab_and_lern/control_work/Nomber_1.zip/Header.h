#pragma once
#include <iostream>
#include <string>

using namespace std;

double Sum_N(int N);